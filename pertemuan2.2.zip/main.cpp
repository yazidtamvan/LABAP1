#include <iostream>

using namespace std;

int main() {
    int a, b;

    system("CLS");

    // Assignment Operator (=)
    a = 3;
    b = 5;



    // Arithmetical Operator (+, -, *, /, %)
    int tambah = a + b;//fungsi penjumlahan
    int kurang = a - b;//fungsi pengurangan
    int kali = a * b;//fungsi perkalian
    float bagi = (float) a / (float) b;     // fungsi pembagian
    int modulo = a % b;//fungsi sisa bagi/modulos

    cout << "Hasil penjumlahan = " << tambah << endl;// output hasil penjumlahan
    cout << "Hasil pengurangan = " << kurang << endl;// output hasil penurangan
    cout << "Hasil perkalian = " << kali << endl;// output hasil perkalian
    cout << "Hasil pembagian = " << bagi << endl;// output hasil pembagian
    cout << "Hasil sisa bagi = " << modulo << endl;// output hasil sisa bagi



    // Relational Operator
    cout << (a == b) << endl;//sama dengan
    cout << (a > b) << endl;//lebih besar 
    cout << (a >= b) << endl;//lebih besar sama dengan
    cout << (a < b) << endl;//lebih kecil
    cout << (a <= b) << endl;//lebih kecil sama dengan
    cout << (a != b) << endl;//tidak sama dengan



    // Logical Operator (&&, ||, !)
    cout << (true && true) << endl;
    cout << (true && false) << endl;
    cout << (false && true) << endl;
    cout << (false && false) << endl;//logika dan

    cout << (true || true) << endl;
    cout << (true || false) << endl;
    cout << (false || true) << endl;
    cout << (false || false) << endl;//logika atau

    cout << !true << endl;
    cout << !false << endl;//negasi



    // Bitwise Operator (&, |, ^, ~, <<, >>) --> Biner
    cout << (5 & 7) << endl;//bitwise dan
    cout << (5 | 7) << endl;//bitwise atau
    cout << (5 ^ 7) << endl;// bitwise xor
    cout << (~7) << endl;//bitwise negasi
    cout << (7 << 2) << endl;//bitwise shl
    cout << (7 >> 2) << endl;//bitwise shr



    // Shorthand
    a += 7;     // a = a + 7;
    cout << a << endl;

    a -= 7;     // a = a - 7;
    cout << a << endl;

    a *= 7;     // a = a * 7;
    cout << a << endl;

    a /= 7;     // a = a / 7;
    cout << a << endl;



    // Increment & Decrement
    // Pre Increment
    //meningkatkan nilai variabel terlebih dahulu sebelum menggunakannya dalam ekspresi.
    cout << a << endl;
    cout << ++a << endl;

    cout << b << endl;
    cout << ++b << endl;


    // Post Increment
    //menggunakannya dalam ekspresi terlebih dahulu sebelum meningkatkan nilai variabel.
    cout << a++ << endl;
    cout << a << endl;

    cout << b++ << endl;
    cout << b << endl;


    // Pre Decrement
    //mengurangkan nilai variabel terlebih dahulu sebelum menggunakannya dalam ekspresi.
    cout << a << endl;
    cout << --a << endl;

    cout << b << endl;
    cout << -b << endl;

    
    // Post Decrement
    //menggunakannya dalam ekspresi terlebih dahulu sebelum mengurangkan nilai variabel.
    cout << a-- << endl;
    cout << a << endl;

    cout << b-- << endl;
    cout << b << endl;

}  