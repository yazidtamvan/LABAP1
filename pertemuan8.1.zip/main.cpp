#include <iostream>
#include <vector>

using namespace std;

class Mahasiswa {
    //? Access Modifier: Private
    private:
        string nama, nim;
        float nilai;

    //? Access Modifier: Public
    public:
        //? Constructor: Fungsi yang langsung dipanggil ketika class diinstansiasi
        Mahasiswa(string nama, string nim, float nilai) {
            this->nama = nama;
            this->nim = nim;
            this->nilai = nilai;
        }

        //? Getter Function: Berfungsi untuk mengembalikan data sebuah variabel yang memiliki akses private
        string getName() {
            return this->nama;
        }

        void display() {
            cout << "Nama   : " << this->nama << endl;
            cout << "NIM    : " << this->nim << endl;
            cout << "Nilai  : " << this->nilai << endl;
        }
};

int main() {
    system("cls");

    // Membuat objek Mahasiswa dengan nama "Andi", NIM "231401111", dan nilai 45.6
    Mahasiswa siswa1("Andi", "231401111", 45.6);
    siswa1.display();

    // Error: Tidak dapat mengakses variabel private nama secara langsung
    // cout << siswa1.nama << endl;
    // siswa1.nama = "Budi";
    // cout << siswa1.nama << endl;

    // Menggunakan getter function untuk mengakses variabel private nama
    cout << siswa1.getName() << endl;

    // Membuat vector untuk menyimpan objek Mahasiswa
    vector<Mahasiswa> mahasiswa;
    int n;
    string nama, nim;
    float nilai;

    // Meminta input jumlah mahasiswa
    cout << "Masukkan jumlah mahasiswa : ";
    cin >> n;

    // Loop untuk meminta input data mahasiswa
    for(int i = 0; i < n; i++) {
        cout << "Mahasiswa " << i + 1 << endl;

        // Menggunakan cin.get() untuk menghapus enter yang tersisa di buffer
        cin.get();
        cout << "Masukkan nama : ";
        getline(cin, nama);

        cout << "Masukkan NIM : ";
        cin >> nim;

        cout << "Masukkan nilai : ";
        cin >> nilai;

        // Membuat objek Mahasiswa dengan data yang diinput
        Mahasiswa mhs(nama, nim, nilai);
        mahasiswa.push_back(mhs);
    }

    // Loop untuk menampilkan data mahasiswa
    for(int i = 0; i < n; i++) {
        cout << "Mahasiswa " << i + 1 << endl;
        mahasiswa[i].display();
    }

    return 0;
}