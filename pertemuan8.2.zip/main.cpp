#include <iostream>
#include <vector>

using namespace std;

//? Deklarasi Struct Mahasiswa
struct Mahasiswa {
    string nama, nim;
    float nilai;
};

//? Deklarasi Typedef untuk Struct Mahasiswa (tidak digunakan dalam kode ini)
typedef struct {
    string nama, nim;
    float nilai;
} mhs;

int main() {
    system("cls");

    //? Deklarasi Vector untuk menyimpan objek Mahasiswa
    vector<Mahasiswa> mahasiswa;
    int n;

    // Meminta input banyak mahasiswa
    cout << "Masukkan banyak mahasiswa : ";
    cin >> n;

    // Loop untuk meminta input data mahasiswa
    for(int i = 0; i < n; i++) {
        cout << "Mahasiswa " << i + 1 << endl;

        // Deklarasi objek Mahasiswa untuk menyimpan data mahasiswa
        Mahasiswa mhs;

        // Menggunakan cin.get() untuk menghapus enter yang tersisa di buffer
        cin.get();
        cout << "Masukkan nama : ";
        getline(cin, mhs.nama);

        cout << "Masukkan NIM : ";
        cin >> mhs.nim;

        cout << "Masukkan nilai : ";
        cin >> mhs.nilai;

        // Menambahkan objek Mahasiswa ke vector
        mahasiswa.push_back(mhs);
    }

    // Loop untuk menampilkan data mahasiswa
    for(int i = 0; i < n; i++) {
        cout << "Mahasiswa " << i + 1 << endl;
        cout << "Nama : " << mahasiswa[i].nama << endl;
        cout << "NIM : " << mahasiswa[i].nim << endl;
        cout << "Nilai : " << mahasiswa[i].nilai << endl;
    }

    return 0;
}