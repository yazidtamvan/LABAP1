#include <stdio.h>
#include <conio.h> 
// untuk menyediakan fungsi-fungsi yang berhubungan dengan manipulasi layar, input/output karakter, dan beberapa operasi lain yang berhubungan dengan konsol.

int main() {
    char nama[50];
    int nim;
    char kom;
    float ip;

    printf("Hello World\n");

    printf("Masukkan nama : ");
    // scanf("%s", &nama);
    gets(nama);     //untuk membaca sebuah baris karakter dari input 

    printf("Masukkan NIM : ");
    scanf("%d", &nim);

    printf("Masukkan KOM : ");
    scanf(" %c", &kom);

    printf("Masukkan IP : ");
    scanf("%f", &ip);

    // printf("Nama : %s\n", nama);
    printf("Nama : ");
    puts(nama);     //untuk menulis sebuah string ke output

    printf("NIM : %d\n", nim);
    printf("KOM : %c\n", kom);
    printf("IP : %.3f\n", ip);

    printf("Press any button to continue...");
    getch();
}