#include <iostream> // Include library input/output stream untuk melakukan input/output

using namespace std; // Menggunakan namespace std untuk mengakses beberapa fungsi tanpa perlu menulis std::

// Fungsi penjumlahan dengan parameter integer
void penjumlahan(int a, int b) {
    cout << a + b << endl; // Menampilkan hasil penjumlahan a dan b
}

// Fungsi penjumlahan dengan parameter pointer integer
void penjumlahanPointer(int* a, int* b) {
    *a += *b; // Menambahkan nilai yang ditunjuk oleh a dan b
    cout << *a << endl; // Menampilkan hasil penjumlahan nilai yang ditunjuk oleh a dan b
}

// Fungsi doubleValue dengan parameter pointer integer
void doubleValue(int* a) {
    *a *= 2; // Mengubah nilai yang ditunjuk oleh a menjadi dua kali lipat
}

int main() {
    system("cls"); // Membersihkan layar console

    //? Pointer Declaration
    //* Variabel normal --> variabel(data), &variabel(alamat memori)
    int number = 35;
    //* Variabel pointer --> variabel(alamat memori variabel yang ditunjuk), &variabel(alamat memori), *variabel(data variabel yang ditunjuk)
    int* pointer_number = &number;

    cout << "Isi variabel number = " << number << endl; // Menampilkan isi variabel number
    cout << "Alamat memori variabel number = " << &number << endl; // Menampilkan alamat memori variabel number
    cout << "Isi variabel pointer_number = " << pointer_number << endl; // Menampilkan isi variabel pointer_number
    cout << "Isi variabel yang ditunjuk oleh pointer_number = " << *pointer_number << endl; // Menampilkan isi variabel yang ditunjuk oleh pointer_number
    cout << "Alamat memori variabel pointer_number = " << &pointer_number << endl; // Menampilkan alamat memori variabel pointer_number

    //? Pointer Operation
    *pointer_number = 25; // Mengubah nilai yang ditunjuk oleh pointer_number menjadi 25
    cout << "Isi variabel number = " << number << endl; // Menampilkan isi variabel number
    cout << "Alamat memori variabel number = " << &number << endl; // Menampilkan alamat memori variabel number
    cout << "Isi variabel pointer_number = " << pointer_number << endl; // Menampilkan isi variabel pointer_number
    cout << "Isi variabel yang ditunjuk oleh pointer_number = " << *pointer_number << endl; // Menampilkan isi variabel yang ditunjuk oleh pointer_number
    cout << "Alamat memori vairabel pointer_number = " << &pointer_number << endl; // Menampilkan alamat memori vairabel pointer_number

    //? Pointer in Array
    int num[] = {1, 2, 3, 4, 5}; // Membuat array num dengan isi 1, 2, 3, 4, 5
    int* pointer_num = num; // Membuat variabel pointer_num dan menunjukkannya ke alamat memori array num

    cout << "Isi variabel num = " << num[0] << endl; // Menampilkan isi variabel num[0]
    cout << "Alamat memori variabel num = " << &num[0] << endl; // Menampilkan alamat memori variabel num
    // cout << "Alamat memori variabel num = " << num << endl; // Menampilkan alamat memori variabel num
    cout << "Isi variabel pointer_num = " <<*pointer_num << endl;
    
    // Menampilkan isi variabel pointer_num yang menunjuk ke alamat memori variabel number
cout << "Isi variabel pointer_num = " << *pointer_num << endl;
cout << "Alamat memori vairabel pointer_num = " << &pointer_num << endl;

//? Pointer in Parameter
// Deklarasi dua buah variabel num1 dan num2
int num1 = 5;
int num2 = 7;

// Memanggil fungsi penjumlahan dengan passing by value
penjumlahan(num1, num2);
cout << num1 << endl;
cout << num2 << endl;

// Memanggil fungsi penjumlahanPointer dengan passing by reference
penjumlahanPointer(&num1, &num2);
cout << num1 << endl;
cout << num2 << endl;

//? Pointer in Pointer
// Deklarasi variabel score dan pointer_score
int score = 4;
int* pointer_score = &score;

// Deklarasi pointer ke pointer_score
int** ptr_pointer_score = &pointer_score;

// Menampilkan isi variabel score dan alamat memorinya
cout << "Isi variabel score " << score << " dan alamat memorinya " << &score << endl;

// Menampilkan isi variabel pointer_score, isi variabel yang ditunjuk oleh pointer_score, dan alamat memori pointer_score
cout << "Isi variabel pointer_score " << pointer_score << " isi variabel yang ditunjuk oleh pointer_score " << *pointer_score << " alamat memori pointer_score " << &pointer_score << endl;

// Menampilkan isi variabel ptr_pointer_score, isi variabel yang ditunjuk oleh ptr_pointer_score, dan alamat memori ptr_pointer_score
cout << "Isi variabel ptr_pointer_score " << pointer_score << " isi variabel yang ditunjuk oleh ptr_pointer_score " << **ptr_pointer_score << " alamat memori ptr_pointer_score " << &ptr_pointer_score << endl;

//? Dynamic Pointer
// Mengalokasikan memori untuk variabel integer dengan operator new
int* ptr = new int;

// Menetapkan nilai untuk variabel integer yang telah dialokasikan memori
*ptr = 30;

// Menampilkan isi variabel ptr dan alamat variabel ptr
cout << "Isi variabel ptr " << *ptr << " alamat variabel ptr " << &ptr << endl;

// Menghapus memori yang telah dialokasikan dengan operator delete
delete ptr;

// Menampilkan isi variabel ptr dan alamat variabel ptr setelah memori dihapus
cout << "Isi variabel ptr " << *ptr << " alamat variabel ptr " << &ptr << endl;

//* Example Code
// Deklarasi variabel n
int n;

// Meminta input angka dari pengguna
cout << "Masukkan sebuah angka : ";
cin >> n;

// Memanggil fungsi doubleValue dengan passing by reference
doubleValue(&n);

// Menampilkan nilai angka setelah dikali 2
cout << "Nilai angka setelah dikali 2 = " << n << endl;

return 0;
}