#include <iostream>

using namespace std;

int main() {
    // Goto Label
    // untuk berpindah ke label tertentu yang telah ditentukan sebelumnya
    goto a; // Mengarahkan eksekusi program ke label 'a'

    a:
    cout << "Hello World" << endl;
    goto d;

    b:
    cout << "Universitas Sumatera Utara" << endl;
    return 0;

    c:
    cout << "Fasilkom-TI" << endl;
    goto b;

    d:
    cout << "Ilmu Komputer" << endl;
    goto c;

    // Looping genap menggunakan goto
    int i = 1;
    genap:
    if (i % 2 == 0) {
        cout << i << " ";
    }
    i++;
    if (i <= 10) {
        goto genap;
    }

    // While
    // untuk membuat loop yang akan menjalankan blok kode berulang kali selama kondisi yang ditentukan bernilai benar (true)
    i = 1; // Menggunakan variabel yang sudah dideklarasikan sebelumnya
    while (i <= 10) {
        if (i % 2 == 0) {
            cout << i << " ";
        }
        i++;
    }
    cout << endl; // Menambahkan newline setelah looping while

    // Do While
    // kondisi diuji sebelum looping
    i = 1; // Menggunakan variabel yang sudah dideklarasikan sebelumnya
    do {
        cout << i << endl;
    } while (i <= 0); // Perbaikan kondisi, seharusnya i > 0 agar perulangan dapat berjalan

    //For
    // untuk membuat perulangan yang biasanya memiliki jumlah iterasi yang telah ditentukan sebelumnya.
    for (int i = 1; i <= 10; i += 2) {
        cout << "Hello World" << endl;
    }

    // Menampilkan persegi bintang
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5; j++) {
            cout << "* ";
        }
        cout << endl;
    }

    // Menampilkan segitiga bintang
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= i; j++) {
            cout << "* ";
        }
        cout << endl;
    }

    return 0;
}
