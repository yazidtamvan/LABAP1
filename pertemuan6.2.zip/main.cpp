#include <iostream>
#include <vector>//untuk menggunakan fungsi vector

using namespace std;

int main() {
    system("cls");

    //? Vector Declaration and Initialization
    //inisiasi vector
    vector<string> nama_karyawan = {"Andi", "Budi", "Santi", "Doni", "Yanto"};

    //? Accessing Elements of Vector
    for (int i = 0; i < nama_karyawan.size(); i++) {
        cout << nama_karyawan[i] << endl;//output nama nama dalam vector
    }

    for (string karyawan : nama_karyawan) {     //* For Each Loop
        cout << karyawan << endl;
    } 

    //? Add Data to Vector
    nama_karyawan.push_back("Wawan");

    //? Delete Data from Vector
    nama_karyawan.pop_back();       //* Menghapus data vector paling akhir
    nama_karyawan.erase(nama_karyawan.begin() + 3);     //* begin() untuk mendapatkan data paling awal, erase() untuk menghapus data
}