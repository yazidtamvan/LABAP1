#include <iostream>

using namespace std;

int main() {
    float luas, p, l;

    //? const float PHI = 3.14;

    cout << "Masukkan panjang : ";
    cin >> p;//untuk input nilai panjang

    cout << "Masukkan lebar : ";
    cin >> l;//untuk input nilai lebar

    luas = p * l;//fungsi/rumus dari luas persegi panjang

    cout << "Luas = " << luas << endl;//output hasil dari luas persegi panjang

    return 0;
}