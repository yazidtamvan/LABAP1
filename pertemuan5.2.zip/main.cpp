#include <iostream>
#include "function_header.h"
// untuk Masukkan
// int kali(int a, int b) {
//     return a * b;
// }

// float bagi(int a, int b) {
//     // return (float) a / (float) b; // type casting
//     return static_cast<float>(a) / static_cast<float>(b);   //type casting
// }
#include "preprocessor.h"
// untuk menggantikan fungsi c++ menjadi
// #define PI 3.14
// #define l <<
// #define r >>
// #define u using namespace std
// #define o cout
// #define i cin
// #define e endl
// #define s system("cls")
// #define begin int main() {
// #define end }
u;

// Function
int tambah(int a, int b) {
    return a + b;
}

int kurang(int a, int b) {
    return a - b;
}

// Procedure
void garis() {
    cout << "==========" << endl;
}

void bintang() {
    cout << "*********" << endl;
}

begin
    s;
    int n;
    garis();
    o l tambah(2, 3) l e;
    o l kurang(2, 3) l e;
    o l kali(2, 3) l e;
    o l bagi(2, 3) l e;
    bintang();
    o l PI l e;
    bintang();
    o l "Masukkan angka : ";
    i r n;
    bintang();
    o l n l e;
end